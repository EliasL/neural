/*
 * tinyADCDendriteites.h
 *
 * Created: 18.06.2018 13:50:42
 * Authors: Bendik Bogfjellmo, Elias Lundheim
 */ 


#ifndef TINYDendriteITE_H_
#define TINYDendriteITE_H_


double tinyDendriteite_update_potential(double potential);

void tinyDendriteite_update_signals(void);


#endif /* TINYADCDendriteITES_H_ */
