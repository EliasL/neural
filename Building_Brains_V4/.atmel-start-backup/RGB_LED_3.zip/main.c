#include <atmel_start.h>
#include <util/delay.h>
#include <stdbool.h>

#include "tinyCCLRGB/tinyCCLRGB.h"


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	while (1)
	{
		
	}
}