/*
 * tinyButton.h
 *
 * Created: 19.06.2018 14:00:58
 * Authors: Bendik Bogfjellmo, Elias Lundheim
 */ 


#ifndef TINYBUTTON_H_
#define TINYBUTTON_H_


void tinyButton_update(void);

double tinyButton_update_potential(double potential);

#endif /* tinyButton_H_ */