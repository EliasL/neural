/*
 * tinyPotential.h
 *
 * Created: 18.06.2018 18:50:30
 * Authors: Bendik Bogfjellmo, Elias Lundheim
 */ 


#ifndef TINYPOTENTIAL_H_
#define TINYPOTENTIAL_H_



void tinyPotential_update(double time_since_last_update);

#endif /* TINY_POTENTIAL_H_ */