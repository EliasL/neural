/*
 * tinyADCdendrites.h
 *
 * Created: 18.06.2018 13:50:42
 * Authors: Bendik Bogfjellmo, Elias Lundheim
 */ 


#ifndef TINYDENDRITE_H_
#define TINYDENDRITE_H_


int16_t tinyDendrite_get_potential();


#endif /* TINYADCDENDRITES_H_ */