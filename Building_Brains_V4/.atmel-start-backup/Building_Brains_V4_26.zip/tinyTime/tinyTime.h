/*
 * tinyTime.h
 *
 * Created: 19.06.2018 13:40:06
 * Authors: Bendik Bogfjellmo, Elias Lundheim
 */ 


#ifndef TINYTIME_H_
#define TINYTIME_H_



void tinyTime_counter_increment(void);
uint32_t tinyTime_now(void);

#endif /* ISR_TIMER_COUNTER_H_ */