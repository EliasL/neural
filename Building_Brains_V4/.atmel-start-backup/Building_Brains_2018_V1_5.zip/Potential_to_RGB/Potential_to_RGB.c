/*
 * Potential_to_RGB.c
 *
 * Created: 18.06.2018 19:48:15
 *  Author: Bendik Bogfjellmo
 */ 

#include <atmel_start.h>
#include <math.h>
#include "tinyCCLRGB/tinyCCLRGB.h"
#include <stdbool.h>

#define number_of_leds 6
#define max_brightness  0x30

/*Okay, so as I see it at the moment, the LEDs should be color-coded to display negative/positive potential.
And the absolute value of the potential should then be linearly displayed along the LEDs.
This, of course is just a prototype and the final decision lies with the design team as well as the group.
I'm only programming this right now so that I've got some base to work on for later.*/
static void potential_to_rgb(double potential)
{
	uint8_t base = abs(floor(potential/8.33333));//base is the amount of LEDs that is turned on max brightness
	
	uint8_t top_floor = abs(round((potential-base)*max_brightness/8.33333));//residual light will be in the top LED decided by how "charged" the upperbound LED should be.
	//By residual light I mean the light that is not dispayed by just maxing the lower LEDs, each LEDs brightness covers about 8.33333 worth of absolute "potential", so to speak.
	if(base > 3)
	{
		base = 2;//covering extreme negative values.
		top_floor = max_brightness;//there needs to be a top_floor included so we don't have to rewrite the entire functionality for one case.
	}
	if(potential < 0)//potential is negative => red color
	{
		for (int i = 0; i < base; i++)
		{
			tinyCCLRGB_setColor(i, max_brightness, 0x0, 0x0);
			tinyCCLRGB_setColor(i+3, max_brightness, 0x0, 0x0);//when programming I've made the assumption that the LEDs will be put on the PCB so that the upper LEDs is LED[0:2]
			//and lower LED is LED[3:5]
		}
		tinyCCLRGB_setColor(base+1, top_floor, 0x0, 0x0);
	}
	if (potential > 0)//potential is positive => positive color.
	{
		for (int i = 0; i< base; i++)
		{
			tinyCCLRGB_setColor(i, 0x0, max_brightness, 0x0);
			tinyCCLRGB_setColor(i+3, 0x0, max_brightness, 0x0);
		}
		tinyCCLRGB_setColor(base+1, 0x0, top_floor, 0x0);
		tinyCCLRGB_setColor(base+4, 0x0, top_floor, 0x0);
	}

}



//this function should be called on to represent that the LEDs have fired, the function will only write to the LEDs once
//and so another update to the LEDs will have to be called to restore them to normal function again.
static void set_LED_fire(void)
{
	for (int i = 0; i < number_of_leds; i++)
	{
		tinyCCLRGB_setColor(i, max_brightness, max_brightness, max_brightness);//This can be set to whatever people like
		//currently I'm in the "all LEDs should be white while firing"-camp, so that's why it's like this.
		tinyCCLRGB_uploadColorsToLeds();
	}
}

void Potential_to_RGB_write_potential_on_LEDs(double potential, _Bool fire)
{
	if (fire)
	{
		set_LED_fire();
	}
	else
	{
		potential_to_rgb(potential);
	}
}