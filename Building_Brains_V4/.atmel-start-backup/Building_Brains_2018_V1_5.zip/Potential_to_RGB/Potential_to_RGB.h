/*
 * Potential_to_RGB.h
 *
 * Created: 18.06.2018 19:47:54
 *  Author: Bendik
 */ 


#ifndef POTENTIAL_TO_RGB_H_
#define POTENTIAL_TO_RGB_H_

void Potential_to_RGB_write_potential_on_LEDs(double potential, _Bool fire);



#endif /* POTENTIAL_TO_RGB_H_ */