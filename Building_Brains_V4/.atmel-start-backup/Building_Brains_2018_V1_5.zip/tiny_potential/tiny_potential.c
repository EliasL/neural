/*
 * tiny_potential.c
 *
 * Created: 18.06.2018 18:50:16
 *  Author: Bendik
 */ 


 //As to preserve modularity, we try to keep any external use of functions to a minimum.
 //


#include <atmel_start.h>
#include "tiny_potential.h"
#include <math.h>
#include "tiny_dendrites/tiny_ADC_dendrites.h"
#include "tiny_DAC_axon/tiny_DAC_axon.h"
#include "Potential_to_RGB/Potential_to_RGB.h"
static double tiny_potential = 0;

#define tiny_potential_time_const 50 //Tau should be equal to 50ms as per the specifications.
#define post_fire_potential -80 //post-fire-potential is described as -80mV in the specs.

//update potential manually when a pulse is recieved or something else.
static void tiny_potential_manual_update(int8_t delta_potential)
{
	tiny_potential += delta_potential;
}

//function to set 
static void tiny_potential_manual_set(int8_t new_potential)
{
	tiny_potential = new_potential;
}


//function to update potential as it should decay over time and converge towards 0.
static void tiny_potential_time_update(double time_since_last_update)//time since last update will have to be given in ms, and therefore needs precision.
{
	tiny_potential *= (1-exp(-(time_since_last_update/tiny_potential_time_const)));
}

void tiny_potential_master_update(double time_since_last_update)
{
	tiny_potential_manual_update(tiny_ADC_dendrite_delta_potential());//update potential from dendrites
	if (tiny_potential > 25)
	{
		tiny_DAC_axon_set_fire();
		tiny_potential_manual_set(post_fire_potential);
		Potential_to_RGB_write_potential_on_LEDs(tiny_potential, true);
	}
	else
	{
		Potential_to_RGB_write_potential_on_LEDs(tiny_potential, false);
	}
	tiny_potential_time_update(time_since_last_update);
}
