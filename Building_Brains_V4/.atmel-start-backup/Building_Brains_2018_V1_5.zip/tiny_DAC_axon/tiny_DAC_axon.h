/*
 * tiny_DAC_axon.h
 *
 * Created: 18.06.2018 16:10:46
 *  Author: Bendik
 */ 


#ifndef TINY_DAC_AXON_H_
#define TINY_DAC_AXON_H_


void tiny_DAC_update_axon(void);
void tiny_DAC_axon_set_fire();
void tiny_DAC_set_neur_type(_Bool neur_type);

#endif /* TINY_DAC_AXON_H_ */