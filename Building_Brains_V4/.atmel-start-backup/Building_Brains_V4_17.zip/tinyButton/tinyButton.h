/*
 * tinyButton.h
 *
 * Created: 19.06.2018 14:00:58
 *  Author: Bendik
 */ 


#ifndef TINYBUTTON_H_
#define TINYBUTTON_H_


_Bool tinyButton_get_state(void);
_Bool tinyButton_is_spont_pulse_on(void);


#endif /* tinyButton_H_ */