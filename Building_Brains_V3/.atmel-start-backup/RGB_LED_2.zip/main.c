#include <atmel_start.h>
#include <util/delay.h>
#include <stdbool.h>

#include "tinyCCLRGB/tinyCCLRGB.h"
//number of leds connected

//tinyCCLRGB_colors[3].red = 0x20;

#typedef bool _Bool

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	uint8_t red = 0;
	uint8_t green = 0;
	uint8_t blue = 0;
	while (1)
	{
		while (red < 0x20)
		{
			red++;
			for (int i = 0; i < 6; i++)
			{
				tinyCCLRGB_setColor(i, red, 0x0, 0x0);
			}
			tinyCCLRGB_uploadColorsToLeds();
			_delay_ms(20);
		}
		while (red > 0x00)
		{
			red--;
			for (int i = 0; i < 6; i++)
			{
				tinyCCLRGB_setColor(i, red, 0x0, 0x0);
			}
			tinyCCLRGB_uploadColorsToLeds();
			_delay_ms(20);
		}
		while (blue < 0x20)
		{
			blue++;
			for (int i = 0; i < 6; i++)
			{
				tinyCCLRGB_setColor(i, 0x0, 0x0, blue);
			}
			tinyCCLRGB_uploadColorsToLeds();
			_delay_ms(20);
		}
		while (blue > 0x00)
		{
			blue--;
			for (int i = 0; i < 6; i++)
			{
				tinyCCLRGB_setColor(i, 0x0, 0x0, blue);
			}
			tinyCCLRGB_uploadColorsToLeds();
			_delay_ms(20);
		}
		while (green < 0x20)
		{
			green++;
			for (int i = 0; i < 6; i++)
			{
				tinyCCLRGB_setColor(i, 0x0, green, 0x0);
			}
			tinyCCLRGB_uploadColorsToLeds();
			_delay_ms(20);
		}
		while (green > 0x00)
		{
			green--;
			for (int i = 0; i < 6; i++)
			{
				tinyCCLRGB_setColor(i, 0x0, green, 0x0);
			}
			tinyCCLRGB_uploadColorsToLeds();
			_delay_ms(20);
		}
	}
}