#include <atmel_start.h>
#include <util/delay.h>
#include <stdbool.h>
#include "tinyCCLRGB/tinyCCLRGB.h"
#include "tiny_dendrites/tiny_ADC_dendrites.h"

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	VREF.CTRLA = 0x33;
	while (1)
	{
		
	}
}