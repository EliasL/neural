/*
 * tiny_ADC_dendrites.c
 *
 * Created: 18.06.2018 13:50:15
 *  Author: Bendik Bogfjellmo
 */ 
#include <atmel_start.h>
#include <math.h>
#include "tiny_dendrites/tiny_ADC_dendrites.h"

#define tiny_ADC_dendrite_number 5//number of dendrites

//enum type for singal.
enum tiny_ADC_dendrite_signal_type
{
	no_signal, low_inhib_signal, high_inhib_signal, low_excite_signal, high_excite_signal
};

uint8_t tiny_ADC_values[5] = {0};//current ADC values
uint8_t dendrite_ports[5] = {5, 7, 9, 10, 11};//ports used on the ADC MUX.
enum tiny_ADC_dendrite_signal_type tiny_ADC_dendrite_cur_signals[5] = {no_signal};
enum tiny_ADC_dendrite_signal_type tiny_ADC_dendrite_prev_signals[5] = {no_signal};


static void tiny_ADC_dendrites_update_values(void)
{
	for (int i = 0; i < tiny_ADC_dendrite_number; i++)
	{
		tiny_ADC_values[i] = ADC_get_conversion(dendrite_ports[i]);
	}
}

static void tiny_ADC_update_signal(void)
{
	for (int i = 0; i < tiny_ADC_dendrite_number; i++)
	{
		tiny_ADC_dendrite_prev_signals[i] = tiny_ADC_dendrite_cur_signals[i];
		tiny_ADC_dendrite_cur_signals[i] = floor(tiny_ADC_values[i] / 51);
		if (tiny_ADC_dendrite_cur_signals[i] == tiny_ADC_dendrite_prev_signals[i])
		{
			tiny_ADC_dendrite_cur_signals[i] = no_signal;
		}
	}
}

uint8_t tiny_ADC_dendrite_delta_potential()
{
	tiny_ADC_dendrites_update_values();
	tiny_ADC_update_signal();
	uint8_t return_potential_val = 0;
	for (int i = 0; i < tiny_ADC_dendrite_number; i++)
	{
		switch(tiny_ADC_dendrite_cur_signals[i])
		{
			case no_signal:
				break;
			case high_excite_signal:
				return_potential_val += 26;
				break;
			case low_excite_signal:
				return_potential_val += 20;
				break;
			case high_inhib_signal:
				return_potential_val -= 26;
				break;
			case low_inhib_signal:
				return_potential_val -=20;
			default:
				break;
		}
	}
	return return_potential_val;
}
