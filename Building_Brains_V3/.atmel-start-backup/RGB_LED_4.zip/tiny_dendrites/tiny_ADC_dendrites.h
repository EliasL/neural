/*
 * tinyADCdendrites.h
 *
 * Created: 18.06.2018 13:50:42
 *  Author: Bendik
 */ 


#ifndef TINY_ADC_DENDRITES_H_
#define TINY_ADC_DENDRITES_H_


uint8_t tiny_ADC_dendrite_delta_potential();


#endif /* TINYADCDENDRITES_H_ */