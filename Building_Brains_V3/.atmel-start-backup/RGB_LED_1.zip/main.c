#include <atmel_start.h>
#include <util/delay.h>

#include "tinyCCLRGB/tinyCCLRGB.h"
//number of leds connected

//tinyCCLRGB_colors[3].red = 0x20;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	while (1)
	{
		tinyCCLRGB_setColor(3, 0x20, 0x00, 0x20);
		tinyCCLRGB_setColor(4, 0x20, 0x20, 0x0);
		tinyCCLRGB_setColor(0, 0x00, 0x20, 0x20);
		tinyCCLRGB_uploadColorsToLeds();
	}
}