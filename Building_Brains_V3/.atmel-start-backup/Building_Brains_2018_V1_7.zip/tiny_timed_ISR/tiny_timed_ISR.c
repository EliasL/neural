/*
 * tiny_ISR_interrupt.c
 *
 * Created: 19.06.2018 00:12:29
 *  Author: Bendik
 */ 



#include <atmel_start.h>
#include <stdbool.h>


static _Bool tiny_timed_ISR_interruptflag = false;


void tiny_timed_ISR_setflag(_Bool new_flag_val)
{
	 _Bool tiny_timed_ISR_interruptflag = new_flag_val;
}

_Bool tiny_timed_ISR_getflag(void)
{
	return tiny_timed_ISR_interruptflag;
}