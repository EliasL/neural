/*
 * tiny_DAC_axon.h
 *
 * Created: 18.06.2018 16:10:46
 *  Author: Bendik
 */ 


#ifndef TINY_DAC_AXON_H_
#define TINY_DAC_AXON_H_


void tiny_DAC_set_neur_type(_Bool neur_type);
void tiny_DAC_axon_master_update(_Bool potential_over_25);

#endif /* TINY_DAC_AXON_H_ */