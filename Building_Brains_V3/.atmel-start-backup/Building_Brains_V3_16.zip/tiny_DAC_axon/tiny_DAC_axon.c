/*
 * tiny_DAC_axon.c
 *
 * Created: 18.06.2018 16:10:31
 *  Author: Bendik
 */ 

#include <atmel_start.h>
#include <stdbool.h>
#include "ISR_timer_counter/ISR_timer_counter.h"


#define axon_delay 100//dendrite delay in ms

/*
Initiates variables for neuron type, axon firing constants etc.
*/
_Bool tiny_DAC_axon_prev = false;
_Bool tiny_DAC_axon_fire = false;

_Bool this_neurons_type;


uint32_t axon_timer_1 = 0;
uint32_t axon_timer_2 = 0;
uint32_t axon_timer_3 = 0;
/*
sets neuron type, should probably be accessible from the master function
of the entire neuron, maybe I'm wrong though.
*/
void tiny_DAC_set_neur_type(_Bool neur_Type)
{
	this_neurons_type = neur_Type;
}



/*
Pulse send function.
sends a pulse dependent on the neurons type.
*/
static void tiny_DAC_axon_send_pulse(void)
{
	if (this_neurons_type)
	{
		DAC_set_output(255);
	}
	else
	{
		DAC_set_output(127);
	}
}


/*
Master update function for the module.
The function should set the DAC to fire for two
update cycles once the pulse flag is set high.
*/
static void tiny_DAC_update_axon(void)
{
	if (tiny_DAC_axon_fire)
	{
		tiny_DAC_axon_fire = false;
		tiny_DAC_axon_send_pulse();
		tiny_DAC_axon_prev = true;
	}
	else if (tiny_DAC_axon_prev)
	{
		tiny_DAC_axon_prev = false;
	}
	else if (!tiny_DAC_axon_prev && !tiny_DAC_axon_fire)
	{
		DAC_set_output(0);
	}
}


/*
function to set firing.
*/
static void tiny_DAC_axon_set_fire()
{
	tiny_DAC_axon_fire = true;
}


/*
Dirty, dirty, dirty solution to add dendrite delay.
This will be functionally the same as required by specs.
Will look into updating if I find a more elegant solution to the problem
that's at least as effective as this one.
*/
void tiny_DAC_axon_master_update(_Bool potential_over_25)
{
	if(potential_over_25)
	{
		if(axon_timer_1 < ISR_timer_count())
		{
			axon_timer_1 = ISR_timer_count()+axon_delay;
		}
		else if (axon_timer_2 < ISR_timer_count())
		{
			axon_timer_2 = ISR_timer_count()+axon_delay;
		}
		else 
		{
			axon_timer_3 = ISR_timer_count()+axon_delay;
		}
	}
	if ((ISR_timer_count() == axon_timer_1) || (ISR_timer_count() == axon_timer_2) || (ISR_timer_count() == axon_timer_3))
	{
		tiny_DAC_axon_set_fire();
	}
	tiny_DAC_update_axon();
}