/*
 * ISR_timer_counter.h
 *
 * Created: 19.06.2018 13:40:06
 *  Author: Bendik
 */ 


#ifndef ISR_TIMER_COUNTER_H_
#define ISR_TIMER_COUNTER_H_



void ISR_timer_counter_increment(void);
uint32_t ISR_timer_count(void);

#endif /* ISR_TIMER_COUNTER_H_ */