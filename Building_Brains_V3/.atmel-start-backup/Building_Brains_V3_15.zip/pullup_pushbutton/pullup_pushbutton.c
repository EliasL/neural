/*
 * pullup_pushbutton.c
 *
 * Created: 19.06.2018 14:01:18
 *  Author: Bendik
 */ 
#include <atmel_start.h>
#include "pullup_pushbutton/pullup_pushbutton.h"
#include <stdbool.h>
#include "tiny_potential/tiny_potential.h"
#include "ISR_timer_counter/ISR_timer_counter.h"


static _Bool pullup_pushbutton_last_check = false;

static uint32_t pullup_pushbutton_start_time = 0;

static _Bool pullup_pushbutton_2sec_holddown = false;

/*
pullup_pushbutton_change_holddown changes the state of the boolean value determining
if the neuron is in spontaneous fire-mode or not.
*/
static void pullup_pushbutton_change_holddown(void)
{
	if (pullup_pushbutton_2sec_holddown)
	{
		pullup_pushbutton_2sec_holddown = false;
	}
	else
	{
		pullup_pushbutton_2sec_holddown = true;
	}
}

/*
function returns true if the button has been pushed and then subsequently released.
function changes state of pullup_pushbutton_2sec_holddown, if button has been held down for 2 secs.
*/
static _Bool pullup_pushbutton_check(void)
{
	if (Button_get_level() && !pullup_pushbutton_last_check)
	{
		return false;
	}
	else if (!Button_get_level() && pullup_pushbutton_last_check)
	{
		if((ISR_timer_count() - pullup_pushbutton_start_time) > 2000)
		{
			pullup_pushbutton_start_time = ISR_timer_count();
			pullup_pushbutton_change_holddown();
		}
		return false;
	}
	else if (Button_get_level() && pullup_pushbutton_last_check)
	{
		return true;
		pullup_pushbutton_last_check = false;
	}
	else if (!Button_get_level() && !pullup_pushbutton_last_check)
	{
		pullup_pushbutton_start_time = ISR_timer_count();
		pullup_pushbutton_last_check = true;
		return false;
	}
	else
	{
		return false;
	}
}





/*
Master-function for button-checking, returns 2 if the neuron should spontaneously fire.
Returns 1 if the system has received a button push shorter than two seconds.
Returns 0 if the button is still pushed in, or it has not yet received a button push.
*/
uint8_t pullup_pushbutton_get_state(void)
{
	_Bool pullup_pushbutton_checker = pullup_pushbutton_check();
	if (pullup_pushbutton_2sec_holddown)
	{
		return 2;
	}
	else if (pullup_pushbutton_checker)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}