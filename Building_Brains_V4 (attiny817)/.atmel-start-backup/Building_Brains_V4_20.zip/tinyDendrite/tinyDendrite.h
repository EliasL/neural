/*
 * tinyADCdendrites.h
 *
 * Created: 18.06.2018 13:50:42
 * Authors: Bendik Bogfjellmo, Elias Lundheim
 */ 


#ifndef TINYDENDRITE_H_
#define TINYDENDRITE_H_


double tinyDendrite_update_potential(double potential);

void tinyDendrite_update_signals(void);


#endif /* TINYADCDENDRITES_H_ */