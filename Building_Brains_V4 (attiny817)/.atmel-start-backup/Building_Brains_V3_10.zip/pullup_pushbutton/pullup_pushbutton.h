/*
 * pullup_pushbutton.h
 *
 * Created: 19.06.2018 14:00:58
 *  Author: Bendik
 */ 


#ifndef PULLUP_PUSHBUTTON_H_
#define PULLUP_PUSHBUTTON_H_


uint8_t pullup_pushbutton_get_state(void);


#endif /* PULLUP_PUSHBUTTON_H_ */