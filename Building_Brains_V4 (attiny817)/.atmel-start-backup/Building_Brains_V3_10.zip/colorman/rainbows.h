/*
 * rainbows.h
 *
 * Created: 18.06.2018 18:27:56
 *  Author: Bendik
 */ 


#ifndef RAINBOWS_H_
#define RAINBOWS_H_


void rainbows();


#endif /* RAINBOWS_H_ */