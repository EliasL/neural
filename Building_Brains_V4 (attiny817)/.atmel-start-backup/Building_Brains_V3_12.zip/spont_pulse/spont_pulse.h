/*
 * spont_pulse.h
 *
 * Created: 20.06.2018 14:34:02
 *  Author: Bendik
 */ 


#ifndef SPONT_PULSE_H_
#define SPONT_PULSE_H_


uint8_t spont_pulse_delta_potential(void);


#endif /* SPONT_PULSE_H_ */