/*
 * tiny_DAC_axon.c
 *
 * Created: 18.06.2018 16:10:31
 *  Author: Bendik
 */ 

#include <atmel_start.h>
#include <stdbool.h>


_Bool tiny_DAC_axon_prev = false;
_Bool tiny_DAC_axon_fire = false;

_Bool this_neurons_type = 1;//setter variabel for nevrontype med eksitatorisk som standard.

void tiny_DAC_set_neur_type(_Bool neur_Type)
{
	this_neurons_type = neur_Type;
}




static void tiny_DAC_axon_send_pulse(void)
{
	if (this_neurons_type)
	{
		DAC_set_output(255);
	}
	else if(!this_neurons_type)
	{
		DAC_set_output(127);
	}
}



void tiny_DAC_update_axon(void)
{
	if (tiny_DAC_axon_fire)
	{
		tiny_DAC_axon_fire = false;
		tiny_DAC_axon_send_pulse();
		tiny_DAC_axon_prev = true;
	}
	else if (tiny_DAC_axon_prev)
	{
		tiny_DAC_axon_prev = false;
	}
	else if (!tiny_DAC_axon_prev && !tiny_DAC_axon_fire)
	{
		DAC_set_output(0);
	}
}


void tiny_DAC_axon_set_fire()
{
	tiny_DAC_axon_fire = true;
}
