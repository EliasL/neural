/*
 * tiny_potential.h
 *
 * Created: 18.06.2018 18:50:30
 *  Author: Bendik
 */ 


#ifndef TINY_POTENTIAL_H_
#define TINY_POTENTIAL_H_



void tiny_potential_master_update(double time_since_last_update);

#endif /* TINY_POTENTIAL_H_ */