/*
 * tinySleep.h
 *
 * Created: 13.06.2020 13:03:57
 *  Author: Elias Lundheim
 */ 


#ifndef TINYSLEEP_H_
#define TINYSLEEP_H_





#endif /* TINYSLEEP_H_ */