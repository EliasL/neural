/*
 * tinyTester.h
 *
 * Created: 12.06.2020 13:49:25
 *  Author: Elias Lundheim
 */ 


#ifndef TINYTESTER_H_
#define TINYTESTER_H_


void tinyTester_test();



#endif /* TINYTESTER_H_ */